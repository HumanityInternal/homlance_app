package com.homlance.auth.service;

import com.homlance.auth.model.User;

public interface ProfileService {
    void profileSave(User user);
}
