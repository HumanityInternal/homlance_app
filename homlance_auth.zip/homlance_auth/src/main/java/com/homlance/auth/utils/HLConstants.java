package com.homlance.auth.utils;

public class HLConstants {
    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";
    public static final String APPROVED = "APPROVED";
    public static final String DENIED = "DENIED";
    public static final String USER_TRACKING_DESC = "User Tracking By Admin";

    public HLConstants() {
    }
}
