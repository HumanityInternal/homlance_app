-------- Homlance Textile Shopping Application --------

Developed by: Thulasy
Date : 02.02.2024
Frameworks used (BACKEND)  : Spring boot, JPA - Hiberate, JSP
Web-Services: Restful API
Database : MySQL
Frameworks used (FRONTEND) : HTML CSS Bootstrap 4(USER PANEL) &
                                                5(ADMIN PANEL)
                                                JAVASCRIPT
                                                JQUERY
                                                AJAX
                                                JSON




Additional Features:
 Email verification
 Approval - Orders
 Payment Gateway
 Tracking


 LINKS : Bootstrap 4 & 5
 https://icons.getbootstrap.com/?q=list

-------------------------------------------------------