// User registration - usercred

var LOG_USER_NAME = "Enter your email Id!";
var LOG_PASSWORD = "Enter your password!";
var LOG_CONFIRM_PASSWORD = "Enter your confirm password!";
var EMAIL_VALIDATION = "Invalid email address";
var PASSWORD_VALIDATION = "Password should contains atleast 6 and less than 8 character";